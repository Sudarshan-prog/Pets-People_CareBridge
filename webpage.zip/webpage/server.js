const express = require('express');
const cors = require('cors');
const https = require('https');
const fs = require('fs');
const path = require('path');
const NodeCache = require('node-cache');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize cache (TTL: 1 hour)
const responseCache = new NodeCache({ stdTTL: parseInt(process.env.CACHE_DURATION) || 3600 });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname)); // Serve static files

// Load knowledge base
let knowledgeBase = [];
try {
    const data = fs.readFileSync(path.join(__dirname, 'knowledge-base.json'), 'utf8');
    knowledgeBase = JSON.parse(data);
    console.log(`✅ Knowledge base loaded: ${knowledgeBase.length} entries`);
} catch (err) {
    console.error('❌ Error loading knowledge base:', err);
}

// API Keys rotation
const API_KEYS = process.env.GEMINI_API_KEYS
    ? process.env.GEMINI_API_KEYS.split(',').filter(k => !k.includes('YOUR_'))
    : [];

if (API_KEYS.length === 0) {
    console.error('⚠️ WARNING: No valid API keys found in .env file');
}

let currentKeyIndex = 0;
const getNextApiKey = () => {
    if (API_KEYS.length === 0) return null;
    const key = API_KEYS[currentKeyIndex];
    currentKeyIndex = (currentKeyIndex + 1) % API_KEYS.length;
    return key;
};

// Simple rate limiter (per IP)
const requestCounts = new Map();
const RATE_LIMIT = parseInt(process.env.RATE_LIMIT_PER_MINUTE) || 10;

const rateLimiter = (req, res, next) => {
    const ip = req.ip;
    const now = Date.now();

    if (!requestCounts.has(ip)) {
        requestCounts.set(ip, []);
    }

    const timestamps = requestCounts.get(ip).filter(t => now - t < 60000);

    if (timestamps.length >= RATE_LIMIT) {
        return res.status(429).json({
            error: 'Rate limit exceeded. Please try again later.',
            mode: 'fallback'
        });
    }

    timestamps.push(now);
    requestCounts.set(ip, timestamps);
    next();
};

// Local fallback function
const findBestMatchLocal = (userMsg) => {
    const normalizedMsg = userMsg.toLowerCase();
    let bestMatch = null;
    let maxOverlap = 0;
    const userKeywords = normalizedMsg.split(/\s+/).filter(w => w.length > 3);

    knowledgeBase.forEach(qa => {
        let overlap = 0;
        if (normalizedMsg.includes(qa.q.toLowerCase())) overlap += 100;
        userKeywords.forEach(uk => {
            if (qa.q.toLowerCase().includes(uk)) overlap++;
        });
        if (overlap > maxOverlap) {
            maxOverlap = overlap;
            bestMatch = qa;
        }
    });

    if (bestMatch && maxOverlap > 0) return bestMatch.a;
    return "I'm sorry, I don't have a specific answer for that. Please contact our support team.";
};

// Gemini API call function
const callGeminiAPI = (userMessage, apiKey) => {
    return new Promise((resolve, reject) => {
        const contextData = JSON.stringify(knowledgeBase);
        const prompt = {
            contents: [{
                parts: [{
                    text: `You are CareBridge AI, a helpful assistant for a pet care platform.
                    
Use this Knowledge Base to answer: ${contextData}

Question: ${userMessage}

Provide a helpful, concise answer based on the knowledge base. Be friendly and professional.`
                }]
            }]
        };

        const postData = JSON.stringify(prompt);
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = https.request(apiUrl, options, (res) => {
            let data = '';
            res.on('data', (chunk) => { data += chunk; });
            res.on('end', () => {
                if (res.statusCode === 200) {
                    try {
                        const jsonResponse = JSON.parse(data);
                        const answer = jsonResponse.candidates[0].content.parts[0].text;
                        resolve({ success: true, answer, mode: 'ai' });
                    } catch (e) {
                        reject({ success: false, error: 'Failed to parse API response' });
                    }
                } else {
                    const errorData = JSON.parse(data);
                    reject({
                        success: false,
                        error: errorData.error?.message || 'API request failed',
                        statusCode: res.statusCode
                    });
                }
            });
        });

        req.on('error', (e) => reject({ success: false, error: e.message }));
        req.write(postData);
        req.end();
    });
};

// Main chat endpoint
app.post('/api/chat', rateLimiter, async (req, res) => {
    const { message } = req.body;

    if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Invalid message format' });
    }

    console.log(`📩 Received: "${message}"`);

    // Check cache first
    const cacheKey = message.toLowerCase().trim();
    const cachedResponse = responseCache.get(cacheKey);

    if (cachedResponse) {
        console.log(`💾 Cache hit for: "${message}"`);
        return res.json({ ...cachedResponse, cached: true });
    }

    // Try Gemini API
    const apiKey = getNextApiKey();

    if (!apiKey) {
        console.log('⚠️ No API key available, using local fallback');
        const localAnswer = findBestMatchLocal(message);
        return res.json({ answer: localAnswer, mode: 'local' });
    }

    try {
        const result = await callGeminiAPI(message, apiKey);

        // Cache the response
        responseCache.set(cacheKey, result);

        console.log(`✅ AI Response sent`);
        res.json(result);
    } catch (error) {
        console.log(`⚠️ API failed (${error.statusCode || 'unknown'}), using local fallback`);

        // Fallback to local matching
        const localAnswer = findBestMatchLocal(message);
        const fallbackResponse = { answer: localAnswer, mode: 'local' };

        res.json(fallbackResponse);
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        knowledgeBase: knowledgeBase.length,
        apiKeys: API_KEYS.length,
        cache: responseCache.keys().length
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`\n🚀 CareBridge Chatbot Server running on http://localhost:${PORT}`);
    console.log(`📚 Knowledge Base: ${knowledgeBase.length} entries`);
    console.log(`🔑 API Keys: ${API_KEYS.length} configured\n`);
});
